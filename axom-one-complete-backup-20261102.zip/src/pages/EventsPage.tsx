import React, { useState, useEffect } from 'react';
import { District, EventItem } from '../types';
import { EventCard } from '../components/EventCard';
import { api } from '../api';
import { Calendar, PlusCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

interface EventsPageProps {
  districts: District[];
  initialDistrict: string;
}

export const EventsPage: React.FC<EventsPageProps> = ({ districts, initialDistrict }) => {
  const [events, setEvents] = useState<EventItem[]>([]);
  const [selectedDistrict, setSelectedDistrict] = useState(initialDistrict || 'all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadEvents();
  }, [selectedDistrict]);

  const loadEvents = async () => {
    setIsLoading(true);
    try {
      const data = await api.getEvents({ district: selectedDistrict });
      setEvents(data);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '2.25rem', fontWeight: 800, color: 'var(--primary-green)', marginBottom: '0.35rem' }}>
            Assam Cultural & Community Events
          </h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
            Raas Mahotsavs, Bihu celebrations, craft exhibitions, book fairs, and citizen gatherings.
          </p>
        </div>

        <Link to="/submit" className="btn-primary">
          <PlusCircle size={16} /> Submit an Event
        </Link>
      </div>

      {/* District Filter Pill */}
      <div style={{ marginBottom: '2rem', display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
        <span style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-secondary)' }}>Filter by District:</span>
        <select
          className="filter-select"
          style={{ width: 'auto', minWidth: '220px' }}
          value={selectedDistrict}
          onChange={(e) => setSelectedDistrict(e.target.value)}
        >
          <option value="all">All Assam (সকলো জিলা)</option>
          {districts.map((d) => (
            <option key={d.id} value={d.slug}>
              {d.name} ({d.name_as})
            </option>
          ))}
        </select>
      </div>

      {/* Events List */}
      {isLoading ? (
        <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-muted)' }}>Loading events...</div>
      ) : events.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '4rem', background: '#FFFFFF', borderRadius: '16px', border: '1px solid var(--border-subtle)' }}>
          <Calendar size={48} color="var(--gamusa-red)" style={{ margin: '0 auto 1rem auto' }} />
          <h3>No events found for this district</h3>
          <p style={{ color: 'var(--text-muted)', marginTop: '0.5rem' }}>
            Know of an upcoming festival or gathering? Submit it to the public directory!
          </p>
          <Link to="/submit" className="btn-outline" style={{ marginTop: '1rem' }}>
            Submit Event Notice
          </Link>
        </div>
      ) : (
        <div className="events-grid">
          {events.map((evt) => (
            <EventCard key={evt.id} event={evt} />
          ))}
        </div>
      )}
    </div>
  );
};

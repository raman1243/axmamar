import React, { useState, useEffect } from 'react';
import { District, Listing } from '../types';
import { ListingCard } from '../components/ListingCard';
import { api } from '../api';
import { Wrench, PlusCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

interface ServicesPageProps {
  districts: District[];
  initialDistrict: string;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ districts, initialDistrict }) => {
  const [listings, setListings] = useState<Listing[]>([]);
  const [districtFilter, setDistrictFilter] = useState(initialDistrict || 'all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [districtFilter]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const data = await api.getListings({ type: 'service', district: districtFilter });
      setListings(data.listings);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '2.25rem', fontWeight: 800, color: 'var(--primary-green)', marginBottom: '0.35rem' }}>
            Essential Civic & Home Services
          </h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.95rem' }}>
            Electricians, solar installers, emergency technicians, medical clinics, and repair services.
          </p>
        </div>
        <Link to="/submit" className="btn-primary">
          <PlusCircle size={16} /> Register Service
        </Link>
      </div>

      <div style={{ marginBottom: '1.75rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
        <span style={{ fontSize: '0.875rem', fontWeight: 700, color: 'var(--text-secondary)' }}>Filter District:</span>
        <select
          className="filter-select"
          style={{ width: 'auto', minWidth: '220px' }}
          value={districtFilter}
          onChange={(e) => setDistrictFilter(e.target.value)}
        >
          <option value="all">All Assam (সকলো জিলা)</option>
          {districts.map((d) => (
            <option key={d.id} value={d.slug}>
              {d.name} ({d.name_as})
            </option>
          ))}
        </select>
      </div>

      {isLoading ? (
        <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-muted)' }}>Loading services...</div>
      ) : listings.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '4rem', background: '#FFFFFF', borderRadius: '16px' }}>
          <Wrench size={48} color="var(--primary-green)" style={{ margin: '0 auto 1rem auto' }} />
          <h3>No services found for this district</h3>
          <p style={{ color: 'var(--text-muted)', marginTop: '0.5rem' }}>Are you a certified electrician, plumber, or technician? Register your contact!</p>
          <Link to="/submit" className="btn-outline" style={{ marginTop: '1rem' }}>Submit Service Free</Link>
        </div>
      ) : (
        <div className="listings-grid">
          {listings.map((l) => (
            <ListingCard key={l.id} listing={l} />
          ))}
        </div>
      )}
    </div>
  );
};

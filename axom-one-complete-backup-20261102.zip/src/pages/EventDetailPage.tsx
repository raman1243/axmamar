import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { EventItem } from '../types';
import { api } from '../api';
import { sanitizeExternalUrl } from '../utils/security';
import { Calendar, MapPin, User, Globe, ArrowLeft, Share2 } from 'lucide-react';

export const EventDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [event, setEvent] = useState<EventItem | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (slug) loadEvent(slug);
  }, [slug]);

  const loadEvent = async (s: string) => {
    setIsLoading(true);
    try {
      const item = await api.getEventBySlug(s);
      setEvent(item);
    } finally {
      setIsLoading(false);
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (isLoading) return <div style={{ textAlign: 'center', padding: '5rem' }}>Loading event details...</div>;
  if (!event) return (
    <div style={{ textAlign: 'center', padding: '5rem 2rem' }}>
      <h2>Event Not Found</h2>
      <Link to="/events" className="btn-primary" style={{ marginTop: '1.5rem' }}>&larr; Back to Events</Link>
    </div>
  );

  const start = new Date(event.start_at);
  const end = new Date(event.end_at);

  return (
    <div style={{ maxWidth: '860px', margin: '0 auto' }}>
      <div style={{ marginBottom: '1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link to="/events" style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: 'var(--text-secondary)', textDecoration: 'none', fontSize: '0.875rem', fontWeight: 600 }}>
          <ArrowLeft size={16} /> Back to Events
        </Link>
        <button onClick={handleShare} className="btn-outline" style={{ padding: '0.35rem 0.75rem', fontSize: '0.8rem' }}>
          <Share2 size={14} /> {copied ? 'Link Copied!' : 'Share'}
        </button>
      </div>

      <article className="detail-container">
        <header className="detail-header">
          <div style={{ display: 'inline-block', background: 'var(--gamusa-red-soft)', color: 'var(--gamusa-red)', padding: '0.25rem 0.75rem', borderRadius: '999px', fontSize: '0.75rem', fontWeight: 700, marginBottom: '0.75rem' }}>
            CULTURAL & COMMUNITY EVENT
          </div>
          <h1 className="detail-title">{event.title}</h1>
          <div className="detail-meta-row">
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
              <MapPin size={15} color="var(--gamusa-red)" />
              <strong>{event.district_name}</strong> {event.district_name_as && `(${event.district_name_as})`}
            </span>
          </div>
        </header>

        {/* Schedule & Venue Boxes */}
        <div className="info-cards-row">
          <div className="info-box">
            <h4><Calendar size={14} style={{ display: 'inline', verticalAlign: 'middle' }} /> Date & Timing</h4>
            <p style={{ marginTop: '0.25rem' }}>
              {start.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              To: {end.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
            </span>
          </div>

          <div className="info-box">
            <h4><MapPin size={14} style={{ display: 'inline', verticalAlign: 'middle' }} /> Venue / Location</h4>
            <p style={{ marginTop: '0.25rem' }}>{event.venue}</p>
          </div>

          <div className="info-box">
            <h4><User size={14} style={{ display: 'inline', verticalAlign: 'middle' }} /> Organizer</h4>
            <p style={{ marginTop: '0.25rem' }}>{event.organizer}</p>
          </div>
        </div>

        {/* Description */}
        <div style={{ fontSize: '1.05rem', color: 'var(--text-primary)', lineHeight: 1.7, margin: '2rem 0' }}>
          <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--primary-green)', marginBottom: '0.75rem' }}>About this Event</h3>
          <p>{event.description}</p>
        </div>

        {event.source_url && sanitizeExternalUrl(event.source_url) && (
          <div style={{ padding: '1rem', background: 'var(--bg-cream)', borderRadius: 'var(--radius-md)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>Official announcement or registration source:</span>
            <a href={sanitizeExternalUrl(event.source_url)} target="_blank" rel="noopener noreferrer" className="btn-primary" style={{ padding: '0.4rem 0.85rem', fontSize: '0.8rem' }}>
              <Globe size={14} /> Official Link
            </a>
          </div>
        )}
      </article>
    </div>
  );
};

import React from 'react';
import { Link } from 'react-router-dom';
import { EventItem } from '../types';
import { MapPin, ArrowRight } from 'lucide-react';

interface EventCardProps {
  event: EventItem;
}

export const EventCard: React.FC<EventCardProps> = ({ event }) => {
  const startDate = new Date(event.start_at);
  const day = startDate.getDate() || 15;
  const month = startDate.toLocaleString('default', { month: 'short' }).toUpperCase() || 'NOV';

  return (
    <article className="event-card">
      <div className="event-date-badge">
        <span className="event-date-day">{day}</span>
        <span className="event-date-month">{month}</span>
      </div>

      <div className="event-info">
        <h3 className="event-title">
          <Link to={`/events/${event.slug}`} style={{ textDecoration: 'none', color: 'inherit' }}>
            {event.title}
          </Link>
        </h3>

        <div className="event-venue" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          <MapPin size={13} />
          <span>{event.venue}</span>
        </div>

        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '0.75rem', lineHeight: 1.5 }}>
          {event.description.length > 120 ? `${event.description.slice(0, 120)}...` : event.description}
        </p>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
            Organized by: <strong>{event.organizer}</strong>
          </span>
          <Link
            to={`/events/${event.slug}`}
            style={{
              color: 'var(--gamusa-red)',
              fontSize: '0.8rem',
              fontWeight: 700,
              textDecoration: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: '0.2rem',
            }}
          >
            Details <ArrowRight size={13} />
          </Link>
        </div>
      </div>
    </article>
  );
};

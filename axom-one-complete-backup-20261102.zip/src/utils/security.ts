// ============================================================================
// AXOM ONE — Application Security Utilities
// Provides strictly validated URL sanitization, XSS defense, and string bounds
// ============================================================================

const ALLOWED_PROTOCOLS = new Set(['http:', 'https:']);

/**
 * Sanitizes external URLs to prevent javascript:, data:, and other malicious URI scheme vectors.
 * Strictly requires http: or https: protocols.
 */
export function sanitizeExternalUrl(url?: string | null): string {
  if (!url || typeof url !== 'string') return '';
  const trimmed = url.trim();
  if (!trimmed) return '';

  // Prevent javascript: pseudo-protocols with control characters or mixed casing
  // e.g. "java\0script:", "javascript :", "data:text/html"
  const normalized = trimmed.replace(/[\u0000-\u001F\u007F-\u009F\s]/g, '').toLowerCase();
  if (
    normalized.startsWith('javascript:') ||
    normalized.startsWith('data:') ||
    normalized.startsWith('vbscript:') ||
    normalized.startsWith('file:')
  ) {
    return '';
  }

  try {
    const parsed = new URL(trimmed);
    if (!ALLOWED_PROTOCOLS.has(parsed.protocol)) {
      return '';
    }
    return parsed.href;
  } catch {
    // If it's a relative path starting with / or ./, allowed for internal links
    if (trimmed.startsWith('/') && !trimmed.startsWith('//')) {
      return trimmed;
    }
    return '';
  }
}

/**
 * Safely extracts hostname for UI display without throwing unhandled exceptions on invalid inputs.
 */
export function getSafeHostname(url?: string | null, fallback = 'Official Portal'): string {
  if (!url || typeof url !== 'string') return fallback;
  try {
    const parsed = new URL(url.trim());
    return parsed.hostname.replace(/^www\./, '') || fallback;
  } catch {
    return fallback;
  }
}

/**
 * Sanitizes text inputs by stripping non-printable control characters and enforcing max length.
 */
export function sanitizeInput(input: string, maxLength = 1000): string {
  if (!input || typeof input !== 'string') return '';
  // Strip control characters except newline (\n) and carriage return (\r)
  const cleaned = input.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
  return cleaned.trim().slice(0, maxLength);
}

/**
 * Validates standard email address formats.
 */
export function isValidEmail(email: string): boolean {
  if (!email || typeof email !== 'string' || email.length > 254) return false;
  // RFC 5322 compliant pragmatic regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
  return emailRegex.test(email.trim());
}

/**
 * Constant-time string equality check to prevent timing side-channel attacks.
 */
export function constantTimeEqual(a: string, b: string): boolean {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const aLen = a.length;
  const bLen = b.length;
  let diff = aLen ^ bLen;
  const maxLen = Math.max(aLen, bLen);
  for (let i = 0; i < maxLen; i++) {
    const charA = i < aLen ? a.charCodeAt(i) : 0;
    const charB = i < bLen ? b.charCodeAt(i) : 0;
    diff |= charA ^ charB;
  }
  return diff === 0;
}

export const VALID_BEAUTY_CATEGORIES = new Set([
  'tea-tourism',
  'river-experiences',
  'hills-waterfalls',
  'wildlife-birdwatching',
  'heritage-historic',
  'handloom-crafts',
  'festivals-cultural',
  'culinary-experiences',
  'botanical-green',
  'district-travel-guides',
]);

export const VALID_DESTINATION_STATUSES = new Set([
  'draft',
  'pending_review',
  'published',
  'archived',
]);

export interface DestinationValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * Validates a BeautyDestination record against strict schema rules.
 * Enforces geographic bounds, URL integrity, required fields, and category allowlists.
 */
export function validateDestinationRecord(record: any): DestinationValidationResult {
  const errors: string[] = [];

  if (!record || typeof record !== 'object') {
    return { valid: false, errors: ['Record must be a valid JSON object'] };
  }

  // Required fields check
  if (!record.id || typeof record.id !== 'string' || !record.id.trim()) {
    errors.push('Destination id is required');
  }
  if (!record.name || typeof record.name !== 'string' || !record.name.trim()) {
    errors.push('Destination name is required');
  }
  if (!record.category || !VALID_BEAUTY_CATEGORIES.has(record.category)) {
    errors.push(`Invalid category "${record.category}". Must be one of the 10 approved categories.`);
  }
  if (!record.status || !VALID_DESTINATION_STATUSES.has(record.status)) {
    errors.push(`Invalid status "${record.status}". Must be draft, pending_review, published, or archived.`);
  }

  // Descriptions
  if (!record.shortDescription && !record.tagline) {
    errors.push('shortDescription is required');
  }
  if (!record.fullDescription && !record.description) {
    errors.push('fullDescription is required');
  }

  // Geographic coordinates validation (Assam GPS boundary: Lat 24.0° - 28.5°, Lon 89.5° - 96.5°)
  if (record.latitude !== null && record.latitude !== undefined) {
    const lat = Number(record.latitude);
    if (isNaN(lat) || lat < 24.0 || lat > 28.5) {
      errors.push(`Latitude ${record.latitude} is outside valid Assam boundaries (24.0 - 28.5)`);
    }
  }
  if (record.longitude !== null && record.longitude !== undefined) {
    const lon = Number(record.longitude);
    if (isNaN(lon) || lon < 89.5 || lon > 96.5) {
      errors.push(`Longitude ${record.longitude} is outside valid Assam boundaries (89.5 - 96.5)`);
    }
  }

  // URL integrity
  if (record.sourceUrl && !sanitizeExternalUrl(record.sourceUrl)) {
    errors.push(`Invalid or unsafe sourceUrl "${record.sourceUrl}"`);
  }
  if (record.officialWebsite && !sanitizeExternalUrl(record.officialWebsite)) {
    errors.push(`Invalid or unsafe officialWebsite "${record.officialWebsite}"`);
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

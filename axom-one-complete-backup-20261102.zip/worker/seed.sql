-- ============================================================================
-- AXOM ONE — Database Seed Data (Cloudflare D1 / SQLite)
-- Includes all 35 Districts of Assam, Categories, Listings, Events, Submissions,
-- and Initial Administrator Profile.
-- ============================================================================

-- 1. All 35 Administrative Districts of Assam
INSERT OR IGNORE INTO districts (id, name, slug, name_as, is_active, created_at) VALUES
('dist-kamrup-metro', 'Kamrup Metropolitan (Guwahati)', 'kamrup-metropolitan', 'কামৰূপ মহানগৰ', 1, '2026-10-01T00:00:00Z'),
('dist-baksa', 'Baksa', 'baksa', 'বাক্সা', 1, '2026-10-01T00:00:00Z'),
('dist-barpeta', 'Barpeta', 'barpeta', 'বৰপেটা', 1, '2026-10-01T00:00:00Z'),
('dist-bajali', 'Bajali', 'bajali', 'বজালী', 1, '2026-10-01T00:00:00Z'),
('dist-biswanath', 'Biswanath', 'biswanath', 'বিশ্বনাথ', 1, '2026-10-01T00:00:00Z'),
('dist-bongaigaon', 'Bongaigaon', 'bongaigaon', 'বঙাইগাঁও', 1, '2026-10-01T00:00:00Z'),
('dist-cachar', 'Cachar (Silchar)', 'cachar', 'কাছাৰ', 1, '2026-10-01T00:00:00Z'),
('dist-charaideo', 'Charaideo', 'charaideo', 'চৰাইদেউ', 1, '2026-10-01T00:00:00Z'),
('dist-chirang', 'Chirang', 'chirang', 'চিৰাং', 1, '2026-10-01T00:00:00Z'),
('dist-darrang', 'Darrang', 'darrang', 'দৰং', 1, '2026-10-01T00:00:00Z'),
('dist-dhemaji', 'Dhemaji', 'dhemaji', 'ধেমাযী', 1, '2026-10-01T00:00:00Z'),
('dist-dhubri', 'Dhubri', 'dhubri', 'ধুবুৰী', 1, '2026-10-01T00:00:00Z'),
('dist-dibrugarh', 'Dibrugarh', 'dibrugarh', 'ডিব্ৰুগড়', 1, '2026-10-01T00:00:00Z'),
('dist-dima-hasao', 'Dima Hasao (Haflong)', 'dima-hasao', 'ডিমা হাছাও', 1, '2026-10-01T00:00:00Z'),
('dist-goalpara', 'Goalpara', 'goalpara', 'গোৱালপাৰা', 1, '2026-10-01T00:00:00Z'),
('dist-golaghat', 'Golaghat', 'golaghat', 'গোলাঘাট', 1, '2026-10-01T00:00:00Z'),
('dist-hailakandi', 'Hailakandi', 'hailakandi', 'হাইলাকান্দি', 1, '2026-10-01T00:00:00Z'),
('dist-hojai', 'Hojai', 'hojai', 'হোজাই', 1, '2026-10-01T00:00:00Z'),
('dist-jorhat', 'Jorhat', 'jorhat', 'যোৰহাট', 1, '2026-10-01T00:00:00Z'),
('dist-kamrup', 'Kamrup (Rural)', 'kamrup-rural', 'কামৰূপ গ্ৰাম্য', 1, '2026-10-01T00:00:00Z'),
('dist-karbi-anglong', 'Karbi Anglong (Diphu)', 'karbi-anglong', 'কাৰ্বি আংলং', 1, '2026-10-01T00:00:00Z'),
('dist-karimganj', 'Karimganj', 'karimganj', 'কৰিমগঞ্জ', 1, '2026-10-01T00:00:00Z'),
('dist-kokrajhar', 'Kokrajhar', 'kokrajhar', 'কোকৰাঝাৰ', 1, '2026-10-01T00:00:00Z'),
('dist-lakhimpur', 'Lakhimpur', 'lakhimpur', 'লখিমপুৰ', 1, '2026-10-01T00:00:00Z'),
('dist-majuli', 'Majuli', 'majuli', 'মাজুলী', 1, '2026-10-01T00:00:00Z'),
('dist-morigaon', 'Morigaon', 'morigaon', 'মৰিগাঁও', 1, '2026-10-01T00:00:00Z'),
('dist-nagaon', 'Nagaon', 'nagaon', 'নগাঁও', 1, '2026-10-01T00:00:00Z'),
('dist-nalbari', 'Nalbari', 'nalbari', 'নলবাৰী', 1, '2026-10-01T00:00:00Z'),
('dist-sivasagar', 'Sivasagar', 'sivasagar', 'শিৱসাগৰ', 1, '2026-10-01T00:00:00Z'),
('dist-sonitpur', 'Sonitpur (Tezpur)', 'sonitpur', 'শোণিতপুৰ', 1, '2026-10-01T00:00:00Z'),
('dist-south-salmara', 'South Salmara-Mankachar', 'south-salmara-mankachar', 'দক্ষিণ শালমাৰা-মানকাচৰ', 1, '2026-10-01T00:00:00Z'),
('dist-tamulpur', 'Tamulpur', 'tamulpur', 'তামুলপুৰ', 1, '2026-10-01T00:00:00Z'),
('dist-tinsukia', 'Tinsukia', 'tinsukia', 'তিনিচুকীয়া', 1, '2026-10-01T00:00:00Z'),
('dist-udalguri', 'Udalguri', 'udalguri', 'ওদালগুৰি', 1, '2026-10-01T00:00:00Z'),
('dist-west-karbi', 'West Karbi Anglong (Hamren)', 'west-karbi-anglong', 'পশ্চিম কাৰ্বি আংলং', 1, '2026-10-01T00:00:00Z');

-- 2. Core Categories
INSERT OR IGNORE INTO categories (id, name, slug, description, icon, is_active, created_at) VALUES
('cat-businesses', 'Local Businesses', 'businesses', 'Local enterprises, handlooms, organic farming, craft workshops & bookstores', 'Store', 1, '2026-10-01T00:00:00Z'),
('cat-services', 'Essential Services', 'services', 'Emergency contacts, verified electricians, local mechanics, logistics & clinics', 'Wrench', 1, '2026-10-01T00:00:00Z'),
('cat-tourism', 'Tourism & Heritage', 'tourism', 'Historic sattras, national parks, river viewpoints & eco-stays', 'Compass', 1, '2026-10-01T00:00:00Z'),
('cat-opportunities', 'Opportunities & Jobs', 'opportunities', 'Apprenticeships, civil coaching notices, scholarships & youth training', 'GraduationCap', 1, '2026-10-01T00:00:00Z'),
('cat-community', 'Community Notices', 'community', 'Riverbank clean-ups, book fairs, cultural rehearsals & public alerts', 'Megaphone', 1, '2026-10-01T00:00:00Z'),
('cat-crafts', 'Art & Traditional Craft', 'crafts', 'Muga and Eri silk weavers, bell metal artisans & terracotta crafts', 'Palette', 1, '2026-10-01T00:00:00Z');

-- 3. Core Listings
INSERT OR IGNORE INTO listings (id, district_id, category_id, title, slug, description, listing_type, address, contact_email, contact_phone, website_url, opening_hours_json, image_key, source_url, verification_status, moderation_status, is_sponsored, created_at, updated_at, published_at) VALUES
(
    'list-sualkuchi-muga',
    'dist-kamrup',
    'cat-crafts',
    'Sualkuchi Silk Weavers Cooperative',
    'sualkuchi-silk-weavers-cooperative',
    'Generational handloom collective producing certified GI-tagged Golden Muga and Pat silk mekhela sador and stoles. Authentic Assamese motifs woven on traditional throw-shuttle looms.',
    'business',
    'Bhattapara, Sualkuchi, Kamrup District, Assam 781103',
    'contact@sualkuchisilk.org.in',
    '+91-361-2830114',
    'https://example.com/sualkuchi-silk',
    '{"monday":"09:00 - 18:00","tuesday":"09:00 - 18:00","wednesday":"09:00 - 18:00","thursday":"09:00 - 18:00","friday":"09:00 - 18:00","saturday":"09:00 - 17:00","sunday":"Closed"}',
    'sualkuchi-muga.jpg',
    'https://example.com/crafts/sualkuchi',
    'verified',
    'published',
    1,
    '2026-10-15T09:00:00Z',
    '2026-10-25T11:00:00Z',
    '2026-10-15T10:00:00Z'
),
(
    'list-kaziranga-ecotour',
    'dist-golaghat',
    'cat-tourism',
    'Kohora Community Safari Guides & Birdwatching Circle',
    'kohora-community-safari-guides',
    'Registered naturalists and community safari drivers offering ethical wildlife spotting and buffer zone bird walks around Kaziranga UNESCO World Heritage Site.',
    'tourism',
    'Near Range Office, Kohora Central Range, Golaghat, Assam 785609',
    'bookings@kazirangaecotrail.org',
    '+91-3776-262423',
    'https://example.com/kaziranga-community-guides',
    '{"daily":"05:30 - 17:00"}',
    'kaziranga-rhino.jpg',
    'https://example.com/eco-tourism',
    'verified',
    'published',
    0,
    '2026-10-18T10:00:00Z',
    '2026-10-18T10:00:00Z',
    '2026-10-18T12:00:00Z'
),
(
    'list-guwahati-repair-hub',
    'dist-kamrup-metro',
    'cat-services',
    'Brahmaputra Home Appliance & Solar Inverter Works',
    'brahmaputra-appliance-solar-works',
    'Experienced local electrical and solar inverter maintenance service operating across Guwahati East and West. Transparent diagnostics and doorstep service.',
    'service',
    'Beltola Tiniali, Opposite Public Library, Guwahati 781028',
    'support@brahmaputraworks.in',
    '+91-98640-12345',
    'https://example.com/brahmaputra-works',
    '{"monday_to_saturday":"08:30 - 19:30"}',
    'electrical-tools.jpg',
    NULL,
    'unverified',
    'published',
    0,
    '2026-10-20T14:00:00Z',
    '2026-10-20T14:00:00Z',
    '2026-10-20T14:30:00Z'
),
(
    'list-assam-stem-internship',
    'dist-kamrup-metro',
    'cat-opportunities',
    'Assam State Renewable Energy Research Fellowship 2026',
    'assam-state-renewable-energy-fellowship',
    'Six-month paid internship opportunity for engineering and environmental science graduates focusing on solar microgrids and flood-resilient community energy.',
    'opportunity',
    'Guwahati Biotech Park, Amingaon, Guwahati 781031',
    'careers@greenenergyassam.org',
    '+91-361-2690022',
    'https://example.com/assam-fellowships',
    '{"office_hours":"10:00 - 17:00 Weekdays"}',
    NULL,
    'https://example.com/notice/fellowship-2026',
    'verified',
    'published',
    0,
    '2026-10-22T08:00:00Z',
    '2026-10-22T08:00:00Z',
    '2026-10-22T09:00:00Z'
),
(
    'list-sarthebari-bellmetal',
    'dist-barpeta',
    'cat-crafts',
    'Sarthebari Bell Metal Cooperative Society',
    'sarthebari-bell-metal-cooperative',
    'Centuries-old bell-metal guild producing traditional Ban-Bati, Kahi, and Sarai hand-forged by master coppersmiths. High acoustic resonance and traditional health benefits.',
    'business',
    'Main Bazaar, Sarthebari, Barpeta District, Assam 781307',
    'guild@sarthebaribellmetal.co.in',
    '+91-3665-242101',
    'https://example.com/sarthebari-bellmetal',
    '{"daily":"09:00 - 18:00"}',
    'bellmetal-sarai.jpg',
    'https://example.com/crafts/bellmetal',
    'verified',
    'published',
    0,
    '2026-10-24T12:00:00Z',
    '2026-10-24T12:00:00Z',
    '2026-10-24T13:00:00Z'
);

-- 4. Sample Community Events
INSERT OR IGNORE INTO events (id, district_id, title, slug, description, venue, start_at, end_at, organizer, source_url, moderation_status, created_at) VALUES
(
    'evt-majuli-raas-2026',
    'dist-majuli',
    'Majuli Raas Mahotsav 2026',
    'majuli-raas-mahotsav-2026',
    'Annual Vaishnavite cultural festival celebrating Krishna Leela through classical Sattriya drama, Mukha mask-acting, and all-night devotional theatre across historic Sattras.',
    'Kamalabari & Auniati Satra Grounds, Majuli',
    '2026-11-15T18:00:00Z',
    '2026-11-18T23:00:00Z',
    'Majuli Raas Celebration Committee',
    'https://example.com/majuli-raas',
    'published',
    '2026-10-26T10:00:00Z'
),
(
    'evt-guwahati-book-fair',
    'dist-kamrup-metro',
    'Guwahati Lit & Heritage Conclave',
    'guwahati-lit-heritage-conclave',
    'A three-day literary celebration featuring Assamese, Bodo, and North-Eastern authors, vernacular publishing stalls, translation workshops, and regional poetry readings.',
    'Srimanta Sankaradeva Kalakshetra, Panjabari, Guwahati',
    '2026-11-20T10:00:00Z',
    '2026-11-22T20:00:00Z',
    'Assam Writers Guild & Kalakshetra Society',
    'https://example.com/guwahati-litcon',
    'published',
    '2026-10-28T11:00:00Z'
);

-- 5. Sample Submissions (Pending Moderation Queue)
INSERT OR IGNORE INTO submissions (id, listing_id, submitter_name, submitter_email, submission_type, payload_json, moderation_status, reviewer_notes, created_at, reviewed_at) VALUES
(
    'sub-101',
    NULL,
    'Debabrata Gogoi',
    'dgogoi@assamteaheritage.test',
    'business',
    '{"title":"Brahmaputra Organic Green Tea Garden Depot","category_slug":"businesses","district_slug":"jorhat","description":"Smallholder artisanal hand-rolled orthodox and green tea direct from Cinnamara tea gardens. Free tasting and estate tours on weekends.","address":"Cinnamara Ali, Jorhat 785008","contact_phone":"+91-94350-98765","contact_email":"info@assamteaheritage.test"}',
    'pending',
    NULL,
    '2026-10-30T14:20:00Z',
    NULL
);

-- 6. Sample User Reports
INSERT OR IGNORE INTO reports (id, listing_id, reason, description, reporter_contact, status, created_at, resolved_at) VALUES
(
    'rep-201',
    'list-guwahati-repair-hub',
    'Incorrect Weekend Hours',
    'The shop is closed on Sunday afternoon, but listing says daily until 19:30. Please verify with owner.',
    'citizen.observer@guwahati.test',
    'pending',
    '2026-10-30T16:00:00Z',
    NULL
);

-- 7. Initial Seed Administrator (Password: AxomOne2026!Admin)
-- Stored with SHA-256 / PBKDF2 hash: salt $ pbkdf2 $ 100000 iterations
INSERT OR IGNORE INTO admin_users (id, email, password_hash, role, is_active, created_at, last_login_at) VALUES
(
    'usr-superadmin-01',
    'admin@axomone.local',
    'pbkdf2:100000:axomsalt2026:ba341602538f9459035dfef08dbdc59c581eb9b5bb446dc2397ca12af14031a0',
    'superadmin',
    1,
    '2026-10-01T00:00:00Z',
    '2026-10-31T09:00:00Z'
);
